#ifndef __LINUX_KVM_ARM_H
#define __LINUX_KVM_ARM_H

/* arm does not support KVM */

#endif
