#include <stdio.h>
#include <math.h>

typedef int inteiro;

union opa {
	int agora;
};

union {
	int agora;
} opa2;

union opa3 {
	int agora;
} opa4;

union opa wl;

int main () {

	int a = 1;
	tipo1 b;
	union opa wl;

	scanf("%d", &a);
	if ((wilson+1)a > (int)b) {
		printf("a %d\n", a);
		a = pow(a, 2);
	}

	a = (struct wilson*)a;

	return 0;
}
