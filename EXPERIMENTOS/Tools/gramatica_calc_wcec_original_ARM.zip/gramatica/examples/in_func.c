#include <stdio.h>
#include <math.h>

int *fool(int, ...);
int b, q;


#define MAX 20

int *fool (int q, ...) {

	int *a;
	typedef char cc;

	return a;
}

char c, d, e;

typedef long long int lli;

int *fool2 (int q, int b, char c, int d)
{
	int *a;
	typedef char foo3;

	return a;
}

static int fool3 (void) {

	return pow(2,3);
}

int main () {

	int a = 1;
	int* e;
	//char *str, c, d;
	lli b;

	fool3();
	scanf("%d", &a);
	if ( (a+b+b > (int)b) || (a < 0 && a+b != 2) ) {
		printf("a %d %d\n", a, fool3());
		a = pow(fool3(), 2);
	}

	//a = (a == 10) ? 25 : a--;
	a++;
	return 0;
}
