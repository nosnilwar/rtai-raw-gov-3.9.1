#include <stdio.h>
#include <math.h>

typedef int inteiro;

enum wilson { a, b, c, d};

int main () {

	int a = 1;
	inteiro b;
	enum wilson *wl;

	scanf("%d", &a);
	if ((a+1)+a > (inteiro)b) {
		printf("a %d\n", a);
		a = pow(a, 2);
	}

	return 0;
}
